import setuptools

with open("readme.md", "r", encoding="utf-8") as fhand:
    long_description = fhand.read()

setuptools.setup(
    name="ArcheD",
    version="1.0",
    author="Arina Tagmazian",
    author_email="arina.tagmazian@helsinki.fi",
    description=("A novel Residual Neural Network to predict amyloid CSF directly from amyloid PET scan"),
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/artagmaz/arched",
    project_urls={
        "Bug Tracker": "https://github.com/artagmaz/arched/issues",
    },
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    install_requires=["tensorflow","nibabel","numpy","pandas","DateTime"],
    packages=setuptools.find_packages(),
    python_requires=">=3.6",
    entry_points={
        "console_scripts": [
            "arched = ArcheD_v1.cli:main",
        ]
    }
)
