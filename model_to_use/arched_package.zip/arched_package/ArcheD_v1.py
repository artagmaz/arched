#!/usr/bin/env python
# coding: utf-8

# In[37]:


import tensorflow as tf
from tensorflow import keras 
import nibabel as nib
import os
import numpy as np
import pandas as pd
from datetime import datetime


# In[57]:


# path_to_directory - path to folder that contains model, code and folder with PET scans, for ex. '~/abeta/ArcheD_run_example/'
# folder with scans - name of the folder or path to it, for ex. 'scans'
# output_name - name for the output file, for ex. 'arched_amyloid_csf_prediction'
def arched(path_to_directory,folder_with_scans,output_name):
    os.chdir(path_to_directory)
    model = keras.models.load_model('model_08-0.12_20_10_22.h5')
    pet_scans_path = os.listdir(folder_with_scans)
    pet_scans_path_full = []
    for i in range(len(pet_scans_path)):
        pet_scans_path_full.append(os.path.join(folder_with_scans, pet_scans_path[i]))
        
    pet_scans_or = []


    for img in pet_scans_path_full: #!!
        imag=nib.load(img)
        image = imag.get_fdata()
        pet_scans_or.append(image)

    pet_scans = np.asarray(pet_scans_or)
    
    prediction = model.predict(pet_scans, batch_size = 4)
    
    output = pd.DataFrame()
    output['PET scan ID'] = pet_scans_path_full
    output['prediction - ln(amyloid CSF)'] = prediction
    output['prediction - amyloid CSF (pg/mL, Roche Elecsys)'] = np.exp(prediction)
    
    d1 = datetime.now().strftime("%H%M_%m%d%Y")
    output.to_csv(output_name+d1+'.csv')

