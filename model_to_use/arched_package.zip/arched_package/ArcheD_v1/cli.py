"""
The command-line interface for running ArcheD model v1.0
"""
import argparse
from .ArcheD_v1 import arched


def main():
    parser = argparse.ArgumentParser(
        description="A novel residual neural network for predicting amyloid CSF directly from amyloid PET scans"
    )
    parser.add_argument(
        "path_to_directory", type=str,
        help="the path to folder that contains model, code and folder with PET scans, for ex. '~/abeta/ArcheD_run_example/'"
    )
    parser.add_argument(
        "folder_with_scans", type=str,
        help="the name of the folder with scans or the path to it, for ex. 'scans'"
    )
    parser.add_argument(
        "--output_name", "-o",
        help=("name for the output file, for ex. 'arched_amyloid_csf_prediction'")
    )
    args = parser.parse_args()
    csf_prediction = arched(args.path_to_directory, args.folder_with_scans, args.output_name)
    print("Model run successfully!")

if __name__ == "__main__":
    main()
